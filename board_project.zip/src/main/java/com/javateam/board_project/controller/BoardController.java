package com.javateam.board_project.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.javateam.board_project.domain.BoardVO;
import com.javateam.board_project.domain.PageVO;
import com.javateam.board_project.service.BoardService;

import lombok.extern.slf4j.Slf4j;

@Controller
@Slf4j
public class BoardController {
	
	@Autowired
	private BoardService boardService;
	
	@GetMapping("/")
	public String home(Model model) {
		
		log.info("home");
		
		model.addAttribute("boardVO", new BoardVO());
		
		return "redirect:/getAllBoards.do/1";
	}
	
	@PostMapping("writeBoardAction.do")
	public String writeAction(@ModelAttribute("boardVO") BoardVO boardVO) {
		
		log.info("게시글 등록 처리");
		String result = "success";
		
		log.info("boardVO : "+boardVO);
		
		boardService.writeBoard(boardVO);
		
		return result;
	}
	
	@GetMapping("getAllBoards.do/{page}")
	// @ResponseBody
	public String getAllBoards(@PathVariable("page") int page, Model model) {
		
		log.info("게시글 페이징 보기");
		
		int maxSize = boardService.count();
		
		log.info("maxSize : " + maxSize);
		List<BoardVO> boardList = boardService.getAll(page, 10);
		
		// 총 페이지 수
   		int maxPage=(int)((double)maxSize/10 + 0.95); //0.95를 더해서 올림 처리
		// 현재 페이지에 보여줄 시작 페이지 수 (1, 11, 21,...)
   		int startPage = (((int) ((double)page / 10 + 0.9)) - 1) * 10 + 1;
		// 현재 페이지에 보여줄 마지막 페이지 수(10, 20, 30, ...)
   	    int endPage = startPage + 10 - 1;
   	    
   	    if (endPage> maxPage) endPage= maxPage;
   	    
   	    PageVO pageVO = new PageVO();
		pageVO.setEndPage(endPage);
		pageVO.setListCount(boardList.size());
		pageVO.setMaxPage(maxPage);
		pageVO.setPage(page);
		pageVO.setStartPage(startPage);
		
		model.addAttribute("boardList", boardList);
		model.addAttribute("pageVO", pageVO);
		
		return "boardList";
	} //

}
