package com.javateam.board_project.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.javateam.board_project.dao.BoardDao;
import com.javateam.board_project.domain.BoardVO;

import lombok.extern.slf4j.Slf4j;

@Service
@Slf4j
public class BoardServiceImpl implements BoardService {
	
	@Autowired
	private BoardDao dao;

	@Override
	public void writeBoard(BoardVO boardVO) {

		log.info("Service writeBoard");
		dao.save(boardVO);
	}

	@Override
	public List<BoardVO> getAll(int page, int limit) {
		
		log.info("Service getAll");
		
		Pageable pageable = PageRequest.of(page-1, limit);
		Page<BoardVO> list = dao.findAll(pageable);
		
		return list.getContent();
	}

	@Override
	public int count() {

		log.info("Service count");
		
		return (int)dao.count();
	}

}
