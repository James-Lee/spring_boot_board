package com.javateam.board_project.service;

import java.util.List;

import com.javateam.board_project.domain.BoardVO;

public interface BoardService {
	
	void writeBoard(BoardVO boardVO);
	
	List<BoardVO> getAll(int page, int limit);
	
	int count();

}