package com.javateam.board_project.dao;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.repository.PagingAndSortingRepository;

import com.javateam.board_project.domain.BoardVO;

public interface BoardDao extends PagingAndSortingRepository<BoardVO, Integer> {

	BoardVO save(BoardVO boardVO);

	Page<BoardVO> findAll(Pageable pageable);
	
	// S save(BoardVO boardVO);
	long count();

}
